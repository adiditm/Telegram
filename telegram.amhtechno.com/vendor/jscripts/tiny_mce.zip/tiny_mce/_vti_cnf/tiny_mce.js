vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|05 Sep 2010 14:37:20 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|mylogo.php uploadlogo.php jscripts/tiny_mce/plugins/fullscreen/fullscreen.htm berita.php editor.php memtestim.php newsman.php voucherprice.php detopup.php tourdetail.php detwd.php getcust_custom.php mygmap.php upload.php uploadnews.php mmenutext.php
vti_author:SR|SE-PC\\Didit
vti_modifiedby:SR|SE-PC\\Didit
vti_timecreated:TR|05 Sep 2010 14:37:20 -0000
vti_cacheddtm:TX|05 Sep 2010 14:37:20 -0000
vti_filesize:IR|155304
